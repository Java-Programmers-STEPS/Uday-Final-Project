package provider;

public interface DataBaseConnectionProvider {
	String driver="com.mysql.jdbc.Driver";
	String connectionUrl="jdbc:mysql://localhost:3306/dialee";
	String userName="root";
	String passWord="";

}
