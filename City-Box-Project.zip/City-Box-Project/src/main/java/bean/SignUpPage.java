package bean;

public class SignUpPage {
	private String userNameInput,passWordInput,phnInput;
	public String getUserNameInput() {
		return userNameInput;
	}
	public void setUserNameInput(String userNameInput) {
		this.userNameInput = userNameInput;
	}
	public String getPassWordInput() {
		return passWordInput;
	}
	public void setPassWordInput(String passWordInput) {
		this.passWordInput = passWordInput;
	}
	public String getPhnInput() {
		return phnInput;
	}
	public void setPhnInput(String phnInput) {
		this.phnInput = phnInput;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	private int id;
}
