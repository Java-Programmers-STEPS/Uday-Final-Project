package bean;

public class OwnerSignIn {
	private String userNameInput,passWordInput;

	public String getUserNameInput() {
		return userNameInput;
	}

	public void setUserNameInput(String userNameInput) {
		this.userNameInput = userNameInput;
	}

	public String getPassWordInput() {
		return passWordInput;
	}

	public void setPassWordInput(String passWordInput) {
		this.passWordInput = passWordInput;
	}
	

}
